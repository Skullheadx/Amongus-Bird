Amongus Bird
FAILURE Studios

How To Play:
- run the Amongus Bird.exe file
OR
- make a shortcut for the .exe file
- select the shortcut and rename to Amongus Bird
- click on properties
- click on change icon
- navigate through textures folder
- click on "icon.ico"
- click Ok
- open the shortcut ot play

Credits
Lead Graphics Designer
Andrew Montgomery
Lead Graphic Designer
Mark Loh
FAILURE Studios logo & animation
created by
John Holwell